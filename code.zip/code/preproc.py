from utils import fetch_and_proc
from numpy import *

print("Loading & Preproc ...")
X,Y,tfv,lbls = fetch_and_proc("data/imdb.csv")
N,D = X.shape

print("Stacking together, Adding header ...")
XY = column_stack([Y,X])
header = ','.join(lbls[0:-1])
words = ['' for i in range(D)]
for k in tfv.vocabulary_.keys():
    i = tfv.vocabulary_[k]
    words[i] = 'w_'+k
header = header + ',' + ','.join(words)
print(header)

print("Writing out ...")

#savetxt('data/imdb_bow.csv', XY, fmt='%d', delimiter=',', comments='', header=header)
savetxt('data/imdb_bow_part.csv', XY[0:50000], fmt='%d', delimiter=',', comments='', header=header)
