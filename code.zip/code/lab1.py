from numpy import * 
from utils import *
import pandas as pd
set_printoptions(precision=2)

########################
# DATA PREPARATION
########################

print("Load Data")
df = pd.read_csv("data/imdb_bow_part.csv")
L = 28
labels = array(df.columns.values.tolist())[0:L]
data = df.values
random.shuffle(data)

print("Split Data")
N = int(len(data)*2/3)

Y = data[0:N,0:L].astype(float)
X = data[0:N,L:].astype(float)

Y_test = data[N:,0:L]
X_test = data[N:,L:]

N_test,L = Y_test.shape


########################
# EXPLORATION
########################

from matplotlib.pyplot import *

print("Exploration")

# TODO Task 1


from utils import count_up

# TODO Task 2

# TODO Task 3

print("Marginal Dependence")

# TODO Task 4

idx = argsort(-sum(Y,axis=0))[0:min(10,L)]
S = get_cooccurence_matrix(Y[:,idx])
#fig = make_heatmap(S,labels[idx])
#show()

# TODO Task 5

#figure()
#G = make_graph(S,0.0,top10lbls)
axis('off')

print("Conditional Dependence")

from molearn.classifiers import BR
from sklearn.linear_model import LogisticRegression

E = get_errors(BR(h=LogisticRegression()),X,Y,2)

# TODO Task 6

print("Build and Evaluate Classifiers")

from molearn.classifiers.CC import CC
from molearn.classifiers.PS import PS
from molearn.classifiers import MCC
from molearn.core.metrics import Hamming_score, Exact_match, J_index
from time import clock

# TODO Task 7


print("Experiment")

# TODO Task 8

random.seed(42)
iterations = [1, 5, 10, 30]

# ...
