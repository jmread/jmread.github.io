from numpy import *

def get_cooccurence_matrix(X):
    # TODO Task 4
    return None

def get_correlation_matrix(X):
    # TODO Task 6
    return None

from sklearn.model_selection import KFold
#from sklearn.cross_validation import KFold

def get_errors(h=None,X=None,Y=None,k=2):
    '''
        Return the errors of model h on dataset X,y under k-fold cross validation.
    '''
    N,L = Y.shape
    kf = KFold(n_splits=k, shuffle=True) #range(N), n_folds=k, shuffle=True)
    E = zeros((N,L))
    for idx_train, idx_test in kf.split(X):
        # TODO Task 6
        print("fold ..")
    return E

def count_up(Y):
    '''
        Returns a dictionary with each label combination and its frequency in Y
    ''' 
    c = {}
    # TODO Task 3. hint: array_str(y) will return a string representation (single variable) of vector y.
    return c


from matplotlib.pyplot import *

def make_heatmap(S,labels):
    '''
        Return a heatmap on matrix S, labelled with labels.
    '''
    L = len(labels)
    S = S.copy()
    fill_diagonal(S,0.)
    S[triu_indices(L)] = 0
    fig, ax = subplots()
    ax.pcolor(S,cmap=cm.Blues)
    ax.set_yticks(arange(L)+0.5, minor=False)
    ax.set_xticks(arange(L)+0.5, minor=False)
    ax.invert_yaxis()
    ax.xaxis.tick_top()
    ax.set_xticklabels(labels, minor=False, rotation=90)
    ax.set_yticklabels(labels, minor=False)
    return fig

import networkx as nx

def make_graph(A,t,col_names):
    '''
        Returns a graph represinting A, each column (and row) has a name corresponding in col_names. 
        Only connections of greater that that weight t are drawn.
    '''

    max_val = A.max()

    G = nx.Graph()

    L,K = A.shape

    widths = []
    for j in range(L):
        G.add_node(col_names[j])
        for k in range(j+1,K):
            if A[j,k] > t:
                G.add_edge(col_names[j],col_names[k],weight=(A[j,k] / max_val * 30.))
                widths.append(A[j,k] / max_val * 30.)

    pos=nx.spring_layout(G,iterations=10) # positions for all nodes

    # nodes
    nx.draw_networkx_nodes(G,pos,alpha=0.1)

    # edges
    nx.draw_networkx_edges(G,pos, width=widths,alpha=0.5,edge_color='b',style='dashed')

    nx.draw_networkx_labels(G, pos)

    return G

from sklearn.feature_extraction.text import CountVectorizer
import pandas as pd

def fetch_and_proc(fname):
    '''
    returns:
        Y:      label columns
        X:      feature columns (new bag of words representation)
        tfv:    used to obtain the BOW representation
        lbls:   label names
    '''

    print("Load Data")

    data = pd.read_csv(fname, encoding = "ISO-8859-1")
    Yx = data.as_matrix()
    N,LD = Yx.shape
    L = LD - 1
    Y = Yx[:,0:L].astype(float)

    print("Loaded X = %d x 1  and Y = %d x %d" % (N,N,L))

    print("Create BOW Feature Space")
    tf_vectorizer = CountVectorizer(encoding = "ISO-8859-1", decode_error='ignore', max_df=0.95, min_df=2, max_features=1000, stop_words='english')

    text = data["SUMMARY"]                               
    #print(text)
    X = tf_vectorizer.fit_transform(text).toarray()
    N,D = X.shape

    return X,Y,tf_vectorizer,data.columns.values.tolist()


