from utils import fetch_and_proc
from molearn.classifiers import MCC

# TODO Task 9

# ... fetch_and_proc("data/imdb.csv")

